

REQUIREMENTS
~~~~~~~~~~~~

 - Apache 2
    
 - Asterisk 1.2 >=
    
 - MySQL 5.x or PostgreSQL 8.x
    
 - PHP 5 >= 5.2.0
    
 - PHP MODULES :
       * PHP-PGSQL or PHP-MYSQLi
       * PHP-MCRYPT
       * PHP_POSIX
       * PHP-GD
       * PHP-PCNTL
       * PHP-GETTEXT
       * PHP-SQLITE (only if you use the module to pool CDR)
       * PHP PEAR SOAP
 
 - CallBack Module, Python requirements :
       * python >= 2.4
       * python-mysqldb
       * python-psycopg2
       * python-sqlalchemy

 - Monitoring IVR Module
    * Cepstral Text to speech (http://www.cepstral.com)
